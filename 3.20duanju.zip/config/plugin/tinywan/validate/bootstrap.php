<?php
return [
    \Tinywan\Validate\Facade\Validate::class
];
