<?php

use Webman\Event\EventListCommand;

return [
    EventListCommand::class
];