<?php

use Kriss\WebmanEloquentIdeHelper\Command\IdeHelperModelsCommand;

return [
    IdeHelperModelsCommand::class,
];
